function retangulo(lar,alt){

    for (let j = 0; j < alt; j++) {
        var linha="";
        for (let i = 0; i < lar; i++) {
            linha+="*";
        }
        console.log(linha)
    }
}

retangulo(10,10);