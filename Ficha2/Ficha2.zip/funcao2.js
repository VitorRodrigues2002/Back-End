function inverter(){
    var frase="Aula de Back-End"
    console.log(frase.split('').reverse().join(''));
}
inverter();